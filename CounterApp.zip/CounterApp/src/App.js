import logo from './logo.svg';
import './App.css';
import React from 'react';


class App extends React.Component{
  constructor(props)
  {
    super(props);
    this.state ={
      count : 0,
    }
  }

  handleClickInc = () => {
    this.setState(prevState => {
      return{
      count : prevState.count + 1
      }
    });
  }

  handleClickDec = () => {
    this.setState(prevState => {
      return{
      count : prevState.count - 1
    }
    });
  }

  handleClickReset = () => {
    this.setState({
      count : 0
    });
  }

  handleOnChange = (e) => {
    this.setState({
      count : isNaN(parseInt(e.target.value)) ? null : parseInt(e.target.value)
    });
  }

  render(){
  return (
    <section className= "App">
    <div className = "center">
      <h2>Counter : <input type="text" value = { this.state.count } onChange = { this.handleOnChange }></input></h2>

      <button className="button" onClick = { this.handleClickInc.bind(this) }>Increment</button>
      &nbsp;&nbsp;&nbsp;
      <button className="button1" onClick = { this.handleClickDec.bind(this) }>Decrement</button>
      &nbsp;&nbsp;&nbsp;
      <button className="button2" onClick = { this.handleClickReset.bind(this) }>Reset</button>

    </div>
    </section>
  );
}
}

export default App;
